<?php

declare(strict_types=1);

function recoveryExtensionsCssHref(): string
{
    $relative = 'recovery-tool/lib/Recovery/Ui/recovery-acp-extensions.css';
    if (\defined('RECOVERY_PACKAGE_DIR') && \is_file(RECOVERY_PACKAGE_DIR . '/lib/Recovery/Ui/recovery-acp-extensions.css')) {
        return recoveryAssetPublicHref($relative);
    }

    return '';
}

function recoveryWcfSetupDarkCssHref(): string
{
    $relative = 'recovery-tool/lib/Recovery/Ui/recovery-wcfsetup-dark.css';
    if (\defined('RECOVERY_PACKAGE_DIR') && \is_file(RECOVERY_PACKAGE_DIR . '/lib/Recovery/Ui/recovery-wcfsetup-dark.css')) {
        return recoveryAssetPublicHref($relative);
    }

    return '';
}

function recoveryExtensionsCssInline(): string
{
    $path = (\defined('RECOVERY_PACKAGE_DIR') ? RECOVERY_PACKAGE_DIR : __DIR__) . '/recovery-acp-extensions.css';

    return \is_file($path) ? (string) \file_get_contents($path) : '';
}

function recoveryWcfSetupDarkCssInline(): string
{
    $path = (\defined('RECOVERY_PACKAGE_DIR') ? RECOVERY_PACKAGE_DIR : __DIR__) . '/recovery-wcfsetup-dark.css';

    return \is_file($path) ? (string) \file_get_contents($path) : '';
}

function recoveryRenderColorSchemeHeadScript(): void
{
    ?>
    <script data-eager="true">
    (function () {
        var root = document.documentElement;
        var mq = window.matchMedia("(prefers-color-scheme: dark)");
        function apply() {
            root.dataset.colorScheme = mq.matches ? "dark" : "light";
        }
        apply();
        if (typeof mq.addEventListener === "function") {
            mq.addEventListener("change", apply);
        } else if (typeof mq.addListener === "function") {
            mq.addListener(apply);
        }
    }());
    </script>
    <?php
}

function recoveryRenderAcpInlineLayoutCss(): void
{
    ?>
    <style>
        #pageHeaderContainer {
            height: 100px;
        }
        #pageHeader {
            padding: 30px 20px;
        }
        .content {
            margin: 0 auto;
            max-width: 920px;
        }
        .recovery-auth-step[hidden] {
            display: none !important;
        }
    </style>
    <?php
}

/**
 * @param array{value?: int, max?: int, label?: string}|null $wizardProgress
 * @param array<string, mixed>|null $assets
 */
function recoveryRenderPageStart(
    string $documentTitle,
    string $contentTitle = '',
    ?array $assets = null,
    ?array $wizardProgress = null
): void {
    try {
        $assets ??= recoveryGetSetupAssets();
    } catch (\Throwable $ignored) {
        $assets = [
            'stylesheets' => [],
            'WCFSetup.css' => '',
            'woltlabSuite.png' => '',
            'fontAwesomeCss' => '',
            'fontAwesomeLocal' => false,
            'usesCompiledAcpStyle' => false,
            'webComponentsJs' => '',
        ];
    }

    $stylesheets = $assets['stylesheets'] ?? [];
    if ($stylesheets === [] && ($assets['WCFSetup.css'] ?? '') !== '') {
        $stylesheets = [(string) $assets['WCFSetup.css']];
    }

    $usesCompiledAcp = (bool) ($assets['usesCompiledAcpStyle'] ?? false);
    $logoHref = ($assets['woltlabSuite.png'] ?? '') !== '' ? recoveryAssetPublicHref((string) $assets['woltlabSuite.png']) : '';
    $faHref = ($assets['fontAwesomeCss'] ?? '') !== ''
        ? recoveryAssetPublicHref((string) $assets['fontAwesomeCss'])
        : '';
    $faExtra = ($assets['fontAwesomeLocal'] ?? false) ? '' : ' crossorigin="anonymous" referrerpolicy="no-referrer"';

    $extCss = recoveryExtensionsCssHref();
    $extInline = $extCss === '' ? recoveryExtensionsCssInline() : '';
    $darkCss = !$usesCompiledAcp ? recoveryWcfSetupDarkCssHref() : '';
    $darkInline = ($darkCss === '' && !$usesCompiledAcp) ? recoveryWcfSetupDarkCssInline() : '';

    $displayTitle = $contentTitle !== '' ? $contentTitle : $documentTitle;

    \header('Content-Type: text/html; charset=utf-8');
    ?>
<!DOCTYPE html>
<html lang="de" data-color-scheme="system">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= \htmlspecialchars($documentTitle) ?></title>
    <?php foreach ($stylesheets as $stylesheet): ?>
    <link rel="stylesheet" type="text/css" media="screen" href="<?= \htmlspecialchars(recoveryAssetPublicHref((string) $stylesheet)) ?>">
    <?php endforeach; ?>
    <?php if ($faHref !== ''): ?>
    <link rel="stylesheet" href="<?= \htmlspecialchars($faHref) ?>"<?= $faExtra ?>>
    <?php endif; ?>
    <?php recoveryRenderColorSchemeHeadScript(); ?>
    <?php recoveryRenderWoltLabHeadGlobals(); ?>
    <?php recoveryRenderFaIconStyles(); ?>
    <?php recoveryRenderWoltLabWebComponentsScript(); ?>
    <?php recoveryRenderAcpInlineLayoutCss(); ?>
    <?php if ($extCss !== ''): ?>
    <link rel="stylesheet" href="<?= \htmlspecialchars($extCss) ?>">
    <?php elseif ($extInline !== ''): ?>
    <style><?= $extInline ?></style>
    <?php endif; ?>
    <?php if ($darkCss !== ''): ?>
    <link rel="stylesheet" href="<?= \htmlspecialchars($darkCss) ?>">
    <?php elseif ($darkInline !== ''): ?>
    <style><?= $darkInline ?></style>
    <?php endif; ?>
</head>
<body id="tplRecoveryTool" data-template="recoveryTool" class="wcfAcp">
<a id="top"></a>
<div id="pageContainer" class="pageContainer acpPageHiddenMenu">
    <div id="pageHeaderContainer" class="pageHeaderContainer">
        <header id="pageHeader" class="pageHeader">
            <div id="pageHeaderFacade" class="pageHeaderFacade">
                <div class="layoutBoundary">
                    <div id="pageHeaderLogo" class="pageHeaderLogo">
                        <?php if ($logoHref !== ''): ?>
                        <img src="<?= \htmlspecialchars($logoHref) ?>" alt="" style="height:40px;width:281px;">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </header>
    </div>
    <div id="acpPageContentContainer" class="acpPageContentContainer">
        <section id="main" class="main" role="main">
            <div class="layoutBoundary">
                <div id="content" class="content">
                    <header class="contentHeader">
                        <div class="contentHeaderTitle">
                            <h1 class="contentTitle"><?= \htmlspecialchars($displayTitle) ?></h1>
                            <?php if ($wizardProgress !== null): ?>
                            <p class="contentHeaderDescription">
                                <progress id="recoveryWizardProgress" value="<?= (int) ($wizardProgress['value'] ?? 0) ?>" max="<?= (int) ($wizardProgress['max'] ?? 100) ?>" style="width:300px" title="<?= (int) ($wizardProgress['value'] ?? 0) ?>%"><?= (int) ($wizardProgress['value'] ?? 0) ?>%</progress>
                                <?php if (($wizardProgress['label'] ?? '') !== ''): ?>
                                <?= \htmlspecialchars((string) $wizardProgress['label']) ?>
                                <?php endif; ?>
                            </p>
                            <?php endif; ?>
                        </div>
                    </header>
    <?php
}

function recoveryRenderPageEnd(?array $assets = null): void
{
    $baseUrl = '';
    try {
        $baseUrl = recoveryGetSiteBaseUrl();
    } catch (\Throwable $ignored) {
    }
    ?>
                </div>
            </div>
        </section>
    </div>
</div>
<p class="recovery-footer-meta">
    <a href="https://github.com/benjarogit/sc-woltlab-plugin-recovery" target="_blank" rel="noopener">Plugin Recovery Tool</a>
    &copy; <?= \date('Y') ?> Sunny C.
    <?php if ($baseUrl !== ''): ?>
    | <a href="<?= \htmlspecialchars($baseUrl) ?>">Installation</a>
    <?php endif; ?>
    | <a href="https://manual.woltlab.com/de/recovery-tool/" target="_blank" rel="noopener">WoltLab Recovery</a>
</p>
<?php
    recoveryRenderWoltLabUiShell();
    recoveryFormLoadingScript();
?>
</body>
</html>
    <?php
}
